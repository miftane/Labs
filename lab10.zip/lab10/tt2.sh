#!/bin/bash
echo "Input first number:"
read a
echo "Input second number:"
read b
echo "Input kol elements:"
read N
echo "First" $N "number Fib:"
i=1
while [ $i -le $N ]
do
let "d=(($b+$a))"
a=$b
b=$d
let "i+=1"
echo "$b"
done
exit 0
