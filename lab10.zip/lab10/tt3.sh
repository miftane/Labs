#!/bin/bash
stat -c ‘%y %n’ * | sort -rh | line
exit 0
