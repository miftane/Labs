#!/bin/bash
echo "Input number for fac:"
read counter
fac=1
if [$counter -lt 0]
then
echo "Input number:"
else
while [$counter -gt 0]
do
fac=$(($fac*$counter))
counter=$(($counter - 1))
done
echo $fac
fi
exit 0
